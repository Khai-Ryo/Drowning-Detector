/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lmic.h"
#include "NMEA.h"
#include "debug.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct Neo7M_GpsData
{
	float time;
	float latitude;
	float longitude;
	double Speed;
	double Date;
	char N_OR_S;
	char E_OR_W;
	char Data[2000];
	char buffer[100];
	char location[100];

} Neo7M_GpsData;
//#define TX_SIZE 28
//#define GPS_RXSIZE 400
//__attribute__ ((section(".GPS_DMA_Buffer"), used)) uint8_t GPS_Data_Buffer[GPS_RXSIZE] = {0};
//uint8_t GPS_Data_Availlable = 0;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//GGASTRUCT GGA_Struct;
Neo7M_GpsData NEO_GPS;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;

/* USER CODE BEGIN PV */
//int flag = 0;
uint8_t Hour = 0;
uint8_t Min = 0;
uint8_t Sec = 0;
uint8_t Flag = 0;
//char sendData[TX_SIZE] = {0};
//float kinhdo = 0;
//float vido = 0;
// application router ID (LSBF)  < ------- IMPORTANT
static const u1_t APPEUI[8]  = { 0x5F, 0x7D, 0x02, 0xD0, 0x7E, 0xD5, 0xB3, 0x70 };
// unique device ID (LSBF)       < ------- IMPORTANT
static const u1_t DEVEUI[8]  = { 0xDC, 0x7C, 0x05, 0xD0, 0x7E, 0xD5, 0xB3, 0x70 };

// device-specific AES key (derived from device EUI)
static const u1_t DEVKEY[16] = { 0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x05, 0x7C, 0xDC };

//   ABP
static const u1_t NWKSKEY[16] = { 0x3D, 0x69, 0xA4, 0x34, 0xE3, 0x29, 0x8E, 0xB9, 0x1F, 0xE5, 0xA3, 0x68, 0x9B, 0x5B, 0x3E, 0x54 };
static const u1_t APPSKEY[16] = { 0x92, 0xB6, 0xB1, 0xE1, 0xF9, 0xC6, 0xF9, 0x0E, 0xBE, 0xDE, 0x85, 0x86, 0x87, 0x28, 0xE9, 0xB4 };
static const u4_t DEVADDR = 0x260BCF3A;
//   ABP
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */
void deleteBuffer(char* data)
{
  uint8_t len = strlen(data);
  for(uint8_t i = 0; i < len; i++)
  {
		data[i] = 0;
  }
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
extern void radio_irq_handler(u1_t dio);

// generic EXTI IRQ handler for all channels
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin_int){
	// DIO 0
	if(GPIO_Pin_int == DIO0_Pin) {
		// invoke radio handler (on IRQ!)
		radio_irq_handler(0);
	}
	// DIO 1
	if(GPIO_Pin_int == DIO1_Pin) {
	    // invoke radio handler (on IRQ!)
		radio_irq_handler(1);
	}
	// DIO 2
	if(GPIO_Pin_int == DIO2_Pin) {
	    // invoke radio handler (on IRQ!)
	    radio_irq_handler(2);
	}

	if(GPIO_Pin_int == GPIO_PIN_0)
		{
			if(Flag == 0)
				Flag = 1;
			else
				Flag = 0;
		}

}
// provide application router ID (8 bytes, LSBF)
void os_getArtEui (u1_t* buf) {
    memcpy(buf, APPEUI, 8);
}

// provide device ID (8 bytes, LSBF)
void os_getDevEui (u1_t* buf) {
    memcpy(buf, DEVEUI, 8);
}

// provide device key (16 bytes)
void os_getDevKey (u1_t* buf) {
    memcpy(buf, DEVKEY, 16);
}


void Get_GpsData(Neo7M_GpsData* GpsData)
{
	char *p;
	int n;

	HAL_UART_Receive_DMA(&huart2, (uint8_t*)GpsData->Data, 2000);

	p = strstr((char*)GpsData->Data,"GPRMC");

	if(p !=NULL)
	{
		n=0;
		while(*p !='\n')
		{
			GpsData->location[n]=*p;
			n++;
			*p = *(p+n);
		}
		//GPRMC,time,A,latitude,S,longitude,E,speed,COG,Date
		//$GPRMC,023725.000,A,1604.4530,N,10809.1428,E,0.89,306.58,101122,,,A*69
	fscanf(GpsData->location,"GPRMC,%6.3lf,A,%4.4lf,%c,%5.4lf,%c,%lf,,%lf,,,A*69",&GpsData->time,&GpsData->latitude,&GpsData->N_OR_S,&GpsData->longitude,&GpsData->E_OR_W,&GpsData->Speed,&GpsData->Date); // @suppress("Float formatting support")

	float Deg_Val=0.0, Min_Val=0.0, lon=0.0, lat=0.0, Time = 0.0;
	lon = GpsData->longitude;
	lat = GpsData->latitude;
	Time = GpsData->time;
	if((GpsData->E_OR_W=='E' || GpsData->E_OR_W == 'W') && (GpsData->N_OR_S=='N' || GpsData ->N_OR_S == 'S'))
	{
		Deg_Val=(int)(lon/100);
		Min_Val=(lon-(Deg_Val*100))/60;
		//Sec_Val=((lon-(Deg_Val*100))-Min_Val)*100;
		GpsData->longitude=Deg_Val+ Min_Val;

		Deg_Val=(int)((lat/100));
		Min_Val=(lat-(Deg_Val*100))/60;
		//Sec_Val=((lat-(Deg_Val*100))-Min_Val)*10;
		GpsData->latitude= Deg_Val+ Min_Val;
	}

	Hour = (uint8_t)(Time/10000);
	Min = (uint8_t)(Time - (Hour*10000))/100;
	Sec = (uint8_t)(Time - ((Hour*10000)+(Min*100)));


	}

}
//void readsensor()
//{
//	char position[46] = {0};
//	char* GGA_head = 0;
//	char GPS_Tmp_Buffer[100] = {0};
//	GPS_Data_Availlable = 0;
//
//	HAL_UART_Receive_DMA(&huart2, (uint8_t*)GPS_Data_Buffer, GPS_RXSIZE);
//
//	uint32_t Start_Time = HAL_GetTick();
//	while(GPS_Data_Availlable == 0)
//	{
//		uint32_t Now_Time = HAL_GetTick();
//		if (Now_Time - Start_Time > 4000)
//		{
//			break;
//		}
//	}
//
//	GGA_head = strstr((char*)GPS_Data_Buffer, "GPGGA");
//	if (GGA_head != NULL)
//		{
//			memcpy(&GPS_Tmp_Buffer, GGA_head, sizeof(GPS_Tmp_Buffer));
//			if(decodeGGA(GPS_Tmp_Buffer, &GGA_Struct) == 0)
//			{
//				kinhdo = GGA_Struct.lcation.longitude;
//				vido = GGA_Struct.lcation.latitude;
//				debug_str("FIX ON LOCATION:\n");
//				sprintf(position, "Latitude: %3.6f || Longtitude: %3.6f\n", vido, kinhdo); // @suppress("Float formatting support")
//				debug_str(position);
//			}
//			else
//			{
//				debug_str("NO FIX\n");
//				kinhdo = kinhdo;
//				vido = vido;
//			}
//		}
//		else
//		{
//			debug_str("NO GPGGA!\n");
//		}
//	for(uint16_t i = 0; i < GPS_RXSIZE; i++)
//		{
//			GPS_Data_Buffer[i] = 0;
//		}
//}

//static uint16_t mydata[3]; //dummy data
uint8_t data[8];
static osjob_t reportjob;
uint16_t status = 0;
uint32_t LatitudeBinary;
uint32_t LongitudeBinary;
// report sensor value
static void reportfunc (osjob_t* j) {
	//readsensor();
	Get_GpsData(&NEO_GPS); //doc toa do GPS truoc khi gui

	LatitudeBinary = ((61.2548 + 90) / 180) * 16777215;
	LongitudeBinary = ((108.25698 + 180) / 360) * 16777215;

	data[0] = ( LatitudeBinary >> 16 ) & 0xFF;
	data[1] = ( LatitudeBinary >> 8 ) & 0xFF;
	data[2] = LatitudeBinary & 0xFF;

	data[3] = ( LongitudeBinary >> 16 ) & 0xFF;
	data[4] = ( LongitudeBinary >> 8 ) & 0xFF;
	data[5] = LongitudeBinary & 0xFF;

	data[6] = ( Flag >> 8 ) & 0xFF;
	data[7] = Flag & 0xFF;


	LMIC_setTxData2(1, data, sizeof(data), 0);
	deleteBuffer(data);
	os_setTimedCallback(j, os_getTime()+sec2osticks(10), reportfunc);


}

void initfunc (osjob_t* j) {
    // reset MAC state
    LMIC_reset();
    // start joining
    LMIC_startJoining();
    // init done - onEvent() callback will be invoked...

    //   ABP
    uint8_t appskey[sizeof(APPSKEY)];
    uint8_t nwkskey[sizeof(NWKSKEY)];
    memcpy(appskey, APPSKEY, sizeof(APPSKEY));
    memcpy(nwkskey, NWKSKEY, sizeof(NWKSKEY));
    LMIC_setSession (0x1, DEVADDR, nwkskey, appskey);

	#if defined(CFG_eu868)
    // Set up the channels used by the Things Network, which corresponds
    // to the defaults of most gateways. Without this, only three base
    // channels from the LoRaWAN specification are used, which certainly
    // works, so it is good for debugging, but can overload those
    // frequencies, so be sure to configure the full frequency range of
    // your network here (unless your network autoconfigures them).
    // Setting up channels should happen after LMIC_setSession, as that
    // configures the minimal channel set.
    // NA-US channels 0-71 are configured automatically
    LMIC_setupChannel(0, 868100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(1, 868300000, DR_RANGE_MAP(DR_SF12, DR_SF7B), BAND_CENTI);      // g-band
    LMIC_setupChannel(2, 868500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(3, 867100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(4, 867300000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(5, 867500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(6, 867700000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(7, 867900000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
    LMIC_setupChannel(8, 868800000, DR_RANGE_MAP(DR_FSK,  DR_FSK),  BAND_MILLI);      // g2-band
    // TTN defines an additional channel at 869.525Mhz using SF9 for class B
    // devices' ping slots. LMIC does not have an easy way to define set this
    // frequency and support for class B is spotty and untested, so this
    // frequency is not configured here.
    #elif defined(CFG_us915)
    // NA-US channels 0-71 are configured automatically
    // but only one group of 8 should (a subband) should be active
    // TTN recommends the second sub band, 1 in a zero based count.
    // https://github.com/TheThingsNetwork/gateway-conf/blob/master/US-global_conf.json
    LMIC_selectSubBand(1);
    #endif
    // Disable link check validation
    LMIC_setLinkCheckMode(0);
    // TTN uses SF9 for its RX2 window.
    LMIC.dn2Dr = DR_SF9;
    // Set data rate and transmit power for uplink (note: txpow seems to be ignored by the library)
    LMIC_setDrTxpow(DR_SF7,14);

    os_setTimedCallback(&reportjob, os_getTime(), reportfunc);
    //   ABP

}



//////////////////////////////////////////////////
// LMIC EVENT CALLBACK
//////////////////////////////////////////////////

void onEvent (ev_t ev) {
    debug_event(ev);

    switch(ev) {
      // network joined, session established
      case EV_JOINING:
       	  debug_str("try joining\r\n");
       	  break;
      case EV_JOINED:
          debug_led(1);
          break;
      case EV_JOIN_FAILED:
    	  debug_str("join failed\r\n");
    	  break;
      case EV_SCAN_TIMEOUT:
    	  debug_str("EV_SCAN_TIMEOUT\r\n");
		  break;
	  case EV_BEACON_FOUND:
		  debug_str("EV_BEACON_FOUND\r\n");
		  break;
	  case EV_BEACON_MISSED:
		  debug_str("EV_BEACON_MISSED\r\n");
		  break;
	  case EV_BEACON_TRACKED:
		  debug_str("EV_BEACON_TRACKED\r\n");
		  break;
	  case EV_RFU1:
		  debug_str("EV_RFU1\r\n");
		  break;
	  case EV_REJOIN_FAILED:
		  debug_str("EV_REJOIN_FAILED\r\n");
		  os_setTimedCallback(&reportjob, os_getTime(), reportfunc);
		  break;
	  case EV_TXCOMPLETE:
		  debug_str("EV_TXCOMPLETE (includes waiting for RX windows)\r\n");
		  if (LMIC.txrxFlags & TXRX_ACK)
			  debug_str("Received ack\r\n");
		  if (LMIC.dataLen) {
			  debug_str("Received ");
			  debug_str(LMIC.dataLen);
			  debug_str(" bytes of payload\r\n");
		  }
		  break;
	  case EV_LOST_TSYNC:
		  debug_str("EV_LOST_TSYNC\r\n");
		  break;
	  case EV_RESET:
		  debug_str("EV_RESET\r\n");
		  break;
	  case EV_RXCOMPLETE:
		  // data received in ping slot
		  debug_str("EV_RXCOMPLETE\r\n");
		  break;
	  case EV_LINK_DEAD:
		  debug_str("EV_LINK_DEAD\r\n");
		  break;
	  case EV_LINK_ALIVE:
		  debug_str("EV_LINK_ALIVE\r\n");
		  break;
	  default:
		   debug_str("Unknown event\r\n");
		  break;
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_Base_Start_IT(&htim3);    // <-----------  change to your setup
  //HAL_TIM_Base_Start_IT(&htim4);    // <-----------  change to your setup
  __HAL_SPI_ENABLE(&hspi1);      	// <-----------  change to your setup

     osjob_t initjob;

     // initialize runtime env
     os_init();

     // initialize debug library
     debug_init();
     //start joining
     debug_str("START\r\n");
     // setup initial job
     initfunc(&initjob);
     // execute scheduled jobs and events
     os_runloop();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
// execute scheduled jobs and events
	os_runloop();
	return 0;
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1221-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, LED_Pin|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : RST_Pin */
  GPIO_InitStruct.Pin = RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : NSS_Pin */
  GPIO_InitStruct.Pin = NSS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(NSS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DIO0_Pin DIO1_Pin DIO2_Pin */
  GPIO_InitStruct.Pin = DIO0_Pin|DIO1_Pin|DIO2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_Pin PD13 PD14 PD15 */
  GPIO_InitStruct.Pin = LED_Pin|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
	  NVIC_SystemReset();
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
